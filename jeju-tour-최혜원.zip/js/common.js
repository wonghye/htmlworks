$(document).ready(function(){

    //모바일 메뉴 띄움
    $('.openMOgnb').click(function(){
        $('header').addClass('on');
        $('header .header_cont').slideDown('fast');
        $('header .header_area .header_cont .closePop').show();			
    });
    $('header .header_cont .closePop').click(function(){
        $('.header_cont').slideUp('fast');
        $('header').removeClass('on');
    });
})